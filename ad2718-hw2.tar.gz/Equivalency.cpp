/*
 * Equivalency.cpp
 *
 *  Created on: Sep 29, 2011
 *      Author: andrewdunn
 */
#include <iostream>
#include "Equivalency.h"

using namespace std;

Equivalency::Equivalency(int $bLabel) {
	// TODO Auto-generated constructor stub
	bLabel = $bLabel;
//	cout << "new Equivalence " << bLabel << endl;
}

Equivalency::~Equivalency() {
	// TODO Auto-generated destructor stub

}

void Equivalency::addEquivalence(int cLabel) {
	// TODO Auto-generated destructor stub
	equivalentCLabels.push_back(cLabel);
}

int Equivalency::getBLabel(){
	return bLabel;
}

vector<int>Equivalency::getEquivalentCLabels()
{
	return equivalentCLabels;
}

bool Equivalency::testIntersection(Equivalency e)
{
	int i,j;
	for (i = 0; i < equivalentCLabels.size(); i++)
	{
		vector<int> otherLabels = e.equivalentCLabels;
		for (j=0; j<otherLabels.size(); j++)
		{
			if (equivalentCLabels[i]==otherLabels[j])
				return true;
		}
	}
	return false;
}

void Equivalency::addEquivalency(Equivalency e)
{
	int i;
	vector<int> otherLabels = e.equivalentCLabels;
	for (i=0; i<otherLabels.size(); i++)
	{
		equivalentCLabels.push_back(otherLabels[i]);
	}
}




