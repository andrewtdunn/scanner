/*
 * p3.cpp
 *
 *  Created on: Sep 25, 2011
 *      Author: andrewdunn
 *
 *   input labeled images output database of properties
 */


#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "vision_utilities.h"
#include "FoundObject.h"


using namespace std;


vector<FoundObject> objs;

int numCols, numRows;

void describeObjects(Image * im)
{
	numCols =  getNCols(im);
	numRows =  getNRows(im);

	int numObjs = getColors(im);
	for (int k=0; k < numObjs; k++)
	{
		int xPos, yPos;

		FoundObject obj;
		// find x,y pos
		int label = k+1;
		obj.setLabel(label);

		// find xSum ,ySum, area, a, b, c
		int xSum, ySum, area;
		int i,j;
		for (i = 0; i < numRows; i++)
		{
			for (j=0; j < numCols; j++)
			{
				int pixLabel = getPixel(im, i, j);
				if (pixLabel == label)
				{
					// b(x,y) always equal to 1

					// xsum += column num
					xSum += j ;
					// ysum += row num
					ySum += i ;
					area ++;
				}
			}
		}
		cout << "area: " << area<<endl;
		xPos = xSum/area;
		yPos = ySum/area;
		obj.setXPos(xPos);
		obj.setYPos(yPos);

		objs.push_back(obj);
	}




}

void writeDatabase(const char *outputFile)
{
	cout << "writing database" << endl;

	ofstream database;
	database.open (outputFile);
	for (int i = 0; i < objs.size(); i++)
	{
		FoundObject obj = objs[i];
		database << obj.getLabel() <<  " "
				 << obj.getXPos() << " "
				 << obj.getYPos() << endl;
	}

	database.close();
}

void writeImageFile(const char * inputImage,const char * outputImage)
{
	Image newImage;
	Image * im;
	im = &newImage;

	readImage(im, inputImage);
	for (int i = 0; i < objs.size(); i ++)
	{
		// add center dot
		setPixel(im, objs[i].getYPos(), 	objs[i].getXPos(), objs.size()+1);
		setPixel(im, objs[i].getYPos() +1, 	objs[i].getXPos(), objs.size()+1);
		setPixel(im, objs[i].getYPos() -1, 	objs[i].getXPos(), objs.size()+1);
		setPixel(im, objs[i].getYPos(), 	objs[i].getXPos() +1, objs.size()+1);
		setPixel(im, objs[i].getYPos(), 	objs[i].getXPos() -1, objs.size()+1);
		setPixel(im, objs[i].getYPos() +1, 	objs[i].getXPos() +1, objs.size()+1);
		setPixel(im, objs[i].getYPos() -1, 	objs[i].getXPos() +1, objs.size()+1);
		setPixel(im, objs[i].getYPos() +1, 	objs[i].getXPos() -1, objs.size()+1);
		setPixel(im, objs[i].getYPos() -1, 	objs[i].getXPos() -1, objs.size()+1);


		// draw line segment for orientation
	}

	setColors(im, objs.size() + 1);

	cout << "writing " << outputImage << endl;
	writeImage(im, outputImage);


}



int main(int argc, char *argv[])
{

	// put command line args into variables
	const char *inputImage = argv[1];
	const char *databaseName = argv[2];
	const char *outputImage =argv[3];

	cout << "input image: " << inputImage << endl;
	cout << "database name: " << databaseName << endl;
	cout << "output image: " << outputImage << endl;

	// use Image struct
	Image newImage;
	Image * im;
	im = &newImage;

	// read image, get # of columns and rows
	readImage(im, inputImage);

	describeObjects(im);
	writeDatabase(databaseName);
	writeImageFile(inputImage, outputImage);


	return 0;
}







