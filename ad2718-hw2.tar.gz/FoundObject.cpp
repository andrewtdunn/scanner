/*
 * FoundObject.cpp
 *
 *  Created on: Sep 29, 2011
 *      Author: andrewdunn
 */

#include "FoundObject.h"

FoundObject::FoundObject() {
	// TODO Auto-generated constructor stub

}

FoundObject::~FoundObject() {
	// TODO Auto-generated destructor stub
}


void FoundObject::setXPos(int $xPos){
	xPos= $xPos;
}

int FoundObject::getXPos(){
	return xPos;
}

void FoundObject::setYPos(int $yPos){
	yPos= $yPos;
}

int FoundObject::getYPos(){
	return yPos;
}

void FoundObject::setLabel(int $label){
	label= $label;
}

int FoundObject::getLabel(){
	return label;
}
