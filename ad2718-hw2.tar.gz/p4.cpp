/*
 * p4.cpp
 *
 *  Created on: Sep 25, 2011
 *      Author: andrewdunn
 *
 * 	compare labeled images against items in a database
 */


#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include "vision_utilities.h"
#include "FoundObject.h"


using namespace std;


int main(int argc, char *argv[])
{

	// put command line args into variables
	const char *inputLabeledImage = argv[1];
	const char *databaseName = argv[2];
	const char *outputImage =argv[3];

	cout << "input labeled image: " << inputLabeledImage << endl;
	cout << "input database name: " << databaseName << endl;
	cout << "output image: " << outputImage << endl;

	// use Image struct
	Image newImage;
	Image * im;
	im = &newImage;

	// read image, get # of columns and rows
	readImage(im, inputLabeledImage);



	return 0;
}


