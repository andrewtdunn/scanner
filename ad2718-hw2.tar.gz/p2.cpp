/*
 * p2.cpp
 *
 *  Created on: Sep 25, 2011
 *      Author: andrewdunn
 *
 *   implementation of sequential labeling algorithm
 *   given an input file out put an image file with each object
 *   labeled with a different shade of gray
 */


#include <iostream>
#include "vision_utilities.h"
#include "Equivalency.h"

using namespace std;


int currentLabel = 0;

// vector of Equivalency objects
vector <Equivalency> eqs;


void addEquivalency(int bLabel, int cLabel)
{
	// search through equivalence vectors to see if it value is there
	// already
	// if so, add to Equivalence
	// if not, create a new Equivalency and add to equivalencies vector
	bool eqFound = false;
	int x,y;
	for (x=0; x<eqs.size(); x++)
	{
	//	cout << "bLabel "<< eqs[x].getBLabel() << endl;

		vector<int>elist = eqs[x].getEquivalentCLabels();
		for (y=0; y<elist.size(); y++)
		{
			if (elist[y] == bLabel )
			{

			//	if (cLabel == 58) cout << "58 found !!!!!!!" << bLabel << " " << cLabel << " " << x <<endl;
				eqs[x].addEquivalence(cLabel);
				eqFound = true;
			}
		}
	}
	if (eqFound != true)
	{
		cout << "new equivalency" << endl;
		Equivalency e(bLabel);
		e.addEquivalence(cLabel);
		eqs.push_back(e);
	}



}



// sequential labeling algorithm
void scanImage(Image * im)
{
	cout << "scanImage" << endl;
	
	int numCols =  getNCols(im);
	int numRows =  getNRows(im);
	
	int i, j;
	// iterate through pixels and reassign brightness based on the threshold value
	for (i=0; i < numRows; i++)
	{
		for (j=0; j < numCols; j++)
		{

			int aLabel = getPixel(im, i, j);
			//1 aLabel = 0 (bkgd)
			if (aLabel == 0)
			{
				// do nothing
			}
			else
			{

			//	cout << "object detected" << endl;


				int dLabel = getPixel(im, i-1, j-1);

				//2 if D has been labeled
				if (dLabel != 0)
				{
					// copy that label and move on
					setPixel(im, i, j, dLabel);
				}

				else
				{
					int bLabel = getPixel(im, i-1 , j);
					int cLabel = getPixel(im, i, j-1);
					//3 if b has been labeled but not c
					if (bLabel != 0 && cLabel == 0 && dLabel == 0)
					{
						setPixel(im,i,j,bLabel);
					}
					//4 if neither b nor c is labeled
					else if (bLabel == 0 && cLabel == 0 && dLabel == 0)
					{
						// make a new label for a
						currentLabel ++;
					//	cout<< "new Label" << currentLabel<< endl;
						setPixel(im, i, j, currentLabel);
					}

					//5 if c has been labeled but not b
					else if (cLabel != 0 && bLabel == 0  && dLabel == 0)
					{
						// set a label to c
						setPixel(im,i,j,cLabel);
					}
					//6 if b and c has been labeled and are equal
					else if ((bLabel !=0 && cLabel != 0) && bLabel == cLabel && dLabel == 0)
					{
						// label a with b
						setPixel(im, i, j, bLabel);
					}
					// 7
					// remaining possibility is that b and c
					// are both labeled but not equal
					// (and d is not labelled)
					else if ((bLabel !=0 && cLabel != 0) && bLabel != cLabel  && dLabel == 0)
					{
						// label a with b
					//	cout << "equivalency found" << endl;
						setPixel(im, i, j, bLabel);
						addEquivalency(bLabel, cLabel);
					}
				}

			}
		}
	}

}






// second pass. resolve equivalencies and adjust total labels
void resolveEquivalencies(Image * im)
{

	// check vector sets for intersection
	// they intersect at 58 in test
	// if an intersection is found, merge vectors

	// still not finding all intersections ....
	int p;

	for (p=0; p< eqs.size(); p++)
	{
		if(eqs[p].testIntersection(eqs[p+1]))
		{
			eqs[p].addEquivalency(eqs[p+1]);
			eqs.erase(eqs.begin()+p+1);
		}
	}





	cout << "resolve equivalencies" << endl;
	int numCols =  getNCols(im);
	int numRows =  getNRows(im);

	int i, j;
	for (i=0; i < numRows; i++)
	{
		for (j=0; j < numCols; j++)
		{

			// loop through eq array

			int label = getPixel(im, i, j);
			for (int e = 0; e < eqs.size(); e++)
			{
				if (label == eqs[e].getBLabel())
					setPixel(im, i, j, e +1);
			}



			int x,y;
			for (x=0; x<eqs.size(); x++)
			{

				vector<int>elist = eqs[x].getEquivalentCLabels();
				for (y=0; y<elist.size(); y++)
				{
					if (elist[y] == label)
					{
						setPixel(im,i,j, x+1);
					}
				}

			}
		}

	}





	setColors(im, eqs.size());
}







void listEquivalencies()
{
	// loop through equivalencies
	cout << "list equivalencies " << endl;
	int x,y;
	for (x=0; x<eqs.size(); x++)
	{
		cout << endl << endl;
		cout << "bLabel "<< eqs[x].getBLabel() << endl;

		vector<int>elist = eqs[x].getEquivalentCLabels();
		for (y=0; y<elist.size(); y++)
		{
			cout << elist[y] << endl;
		}

	}
}





int main(int argc, char *argv[])
{

	// put command line args into variables
	const char *inputFile = argv[1];
	const char *outputFile =argv[2];

	cout << "input file: " << inputFile << endl;
	cout << "output file: " << outputFile << endl;

	// use Image struct
	Image newImage;
	Image * im;
	im = &newImage;

	// read image, get # of columns and rows
	readImage(im, inputFile);


	// sequential labeling algorithm

	scanImage(im);
	listEquivalencies();
	resolveEquivalencies(im);
	listEquivalencies();
	writeImage(im, outputFile);

	return 0;
}







